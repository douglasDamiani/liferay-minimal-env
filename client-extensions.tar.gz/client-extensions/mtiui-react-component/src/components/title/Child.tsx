interface Props {
  title: string
}
function Title({title}: Props) {
  return (
    <h1>Child - {title}</h1>
  )
}
export default Title