#!/bin/bash

# Run MySQL with the --force option
mysql -u "root" -p"$MYSQL_PASSWORD" -e "USE lportal; DELETE IGNORE FROM Configuration_;" --force || true
